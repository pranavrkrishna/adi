from django.db import models

class Imagemap(models.Model):
    Name = models.CharField(max_length=100,default="")
    embeddings = models.BinaryField()