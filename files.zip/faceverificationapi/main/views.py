import os
from rest_framework.views import APIView
from rest_framework.decorators import parser_classes
from rest_framework.parsers import MultiPartParser
from django.http import HttpResponse, response
from django.http import JsonResponse
import json
from django.core.files.storage import FileSystemStorage
from .models import Imagemap
import cv2
import numpy as np
from facegrid import facetools
from scipy.spatial.distance import cosine
from PIL import Image
import json


def getFaces(image):
    return facetools.getFaces(image)


@parser_classes((MultiPartParser, ))
class create(APIView):
    def post(self,request,*args,**kwargs):
        name = request.POST.get("name")
        #read image file string data
        filestr = request.FILES['image'].read()
        #convert string data to numpy array
        npimg = np.fromstring(filestr, np.uint8)
        # convert numpy array to image
        img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
        face = getFaces(img)
        if(len(face) > 1):
            return HttpResponse("Unsuccessfull, image contains more then one face")
        if(len(face) == 0):
             return HttpResponse("Unsuccessfull, No faces detected in the image")
        features = facetools.getEmbeddings(face[0]["face"])
        features = features[0].tobytes()
        Imagemap.objects.create(
            Name = name,
            embeddings = features
        )
        return HttpResponse("status successfull")

def searchDB(face_list):
    name = ""
    d_list = []
    minimum = 1
    for faces in face_list:
        minimum = 1
        face_embedding = facetools.getEmbeddings(faces["face"])[0]
        for image in Imagemap.objects.all():
            compare_img = image.embeddings
            embedding = np.frombuffer(compare_img,'float32')
            score = cosine(embedding,face_embedding)
            if(score < minimum):
                minimum = score
                name = image.Name
        d = {}
        if(minimum > 0.5):
            d["name"] = "unknown"
        else:
            d["name"] = name
        d["features"] = faces["features"]
        d["score"] = minimum
        d_list.append(d)
    return d_list

@parser_classes((MultiPartParser, ))
class detect(APIView):
    def post(self,request,*args,**kwargs):
        #read image file string data
        filestr = request.FILES['image'].read()
        #convert string data to numpy array
        npimg = np.fromstring(filestr, np.uint8)
        # convert numpy array to image
        img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
        face_list = getFaces(img)
        d = searchDB(face_list)
        return JsonResponse(d,safe=False)


