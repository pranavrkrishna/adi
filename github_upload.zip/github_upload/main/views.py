import os
from rest_framework.views import APIView
from rest_framework.decorators import parser_classes
from rest_framework.parsers import MultiPartParser
from django.http import HttpResponse, response
from django.http import JsonResponse
import json
from django.core.files.storage import FileSystemStorage
from .models import Imagemap
import cv2
import numpy as np
from keras_vggface.utils import preprocess_input
from keras_vggface.vggface import VGGFace
from scipy.spatial.distance import cosine
from PIL import Image
import json

# Define paths
base_dir = os.path.dirname(__file__)
prototxt_path = os.path.join(base_dir + '/model_data/deploy.prototxt')
caffemodel_path = os.path.join(base_dir + '/model_data/weights.caffemodel')

# Read the model
model = cv2.dnn.readNetFromCaffe(prototxt_path, caffemodel_path)


def decode_numpy(string):
    string = string[1:-1].split(" ")
    arr = np.array([np.float32(i) for i in string])
    return arr

def getFeatures(faces):
    face = np.asarray(faces,'float32') 
    print(face.shape)
    face = preprocess_input(face,version=2)
    model = VGGFace(model = 'resnet50',include_top=False,input_shape=(224,224,3),pooling='avg')
    return model.predict(face)


def getFaces(image):
    (h, w) = image.shape[:2]
    blob = cv2.dnn.blobFromImage(cv2.resize(image, (300, 300)), 1.0, (300, 300), (104.0, 177.0, 123.0))

    model.setInput(blob)
    detections = model.forward()
    face_img_list = []
    for i in range(0, detections.shape[2]):
        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        (startX, startY, endX, endY) = box.astype("int")
        confidence = detections[0, 0, i, 2]
        # If confidence > 0.5, save it as a separate file
        if (confidence > 0.5):
            frame = image[startY:endY, startX:endX]
            face_img_list.append({
                                "frame":frame,
                                "box":[int(i) for i in [startX,startY,endX,endY]]
                                })
    faces = face_img_list
    face_list = []
    for face in faces:
        face_list.append({
            "image" : cv2.resize(face["frame"],(224,224)),
            "features": {
                "bounding_box": face["box"]
            }
        })
    return face_list


# def extractFaces(image,face,resize = (224,224)):
#     x1, y1, width, height = face['box']
#     x2, y2 = x1 + width, y1 + height
#     face_boundary = image[y1:y2,x1:x2]
#     face_image = cv2.resize(face_boundary,resize)
#     return face_image

@parser_classes((MultiPartParser, ))
class create(APIView):
    def post(self,request,*args,**kwargs):
        name = request.POST.get("name")
        #read image file string data
        filestr = request.FILES['image'].read()
        #convert string data to numpy array
        npimg = np.fromstring(filestr, np.uint8)
        # convert numpy array to image
        img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
        face = getFaces(img)
        if(len(face) > 1):
            return HttpResponse("Unsuccessfull, image contains more then one face")
        if(len(face) == 0):
             return HttpResponse("Unsuccessfull, No faces detected in the image")
        features = getFeatures([face[0]["image"]])
        features = features[0].tobytes()
        Imagemap.objects.create(
            Name = name,
            embeddings = features
        )
        return HttpResponse("status successfull")

def searchDB(face_list):
    name = ""
    d_list = []
    minimum = 1
    for faces in face_list:
        minimum = 1
        face_embedding = getFeatures([faces["image"]])[0]
        for image in Imagemap.objects.all():
            compare_img = image.embeddings
            embedding = np.frombuffer(compare_img,'float32')
            score = cosine(embedding,face_embedding)
            if(score < minimum):
                minimum = score
                name = image.Name
        d = {}
        if(minimum > 0.5):
            d["name"] = "unknown"
        else:
            d["name"] = name
        d["features"] = faces["features"]
        d["score"] = minimum
        d_list.append(d)
    return d_list

@parser_classes((MultiPartParser, ))
class detect(APIView):
    def post(self,request,*args,**kwargs):
        #read image file string data
        filestr = request.FILES['image'].read()
        #convert string data to numpy array
        npimg = np.fromstring(filestr, np.uint8)
        # convert numpy array to image
        img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
        face_list = getFaces(img)
        d = searchDB(face_list)
        return JsonResponse(d,safe=False)


